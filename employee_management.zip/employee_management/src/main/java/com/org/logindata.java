package com.org;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/logindata")
public class logindata extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public logindata() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
        PrintWriter out=response.getWriter();
		
		String user="rohit";
		String pass="1234";
		
		String username=request.getParameter("input1");
		String password=request.getParameter("input2");
		
		if(user.equals(username) && pass.equals(password)) {
			HttpSession session=request.getSession();
			
			session.setAttribute("username", user);
			session.setAttribute("password", pass);
			
			response.sendRedirect("employee.jsp");
		}
		else {
			out.println("sorry!! Invalid Username or password");
		}
	}

}
