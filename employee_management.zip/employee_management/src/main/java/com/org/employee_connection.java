package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/employee_connection")
public class employee_connection extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public employee_connection() {
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String name=request.getParameter("t1");
		int age=Integer.parseInt(request.getParameter("t2"));
		int salary=Integer.parseInt(request.getParameter("t3"));
		String number=request.getParameter("t4");
		String email=request.getParameter("t5");
		String dob=request.getParameter("t6");
		String doj=request.getParameter("t7");
		String dept=request.getParameter("t8");
		String qualification=request.getParameter("t9");
		PrintWriter out=response.getWriter();
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management","root","Rohit@123");
			
			Statement stat=con.createStatement();	
						
			stat.executeUpdate("insert into employee(e_name,e_age,e_salary,e_contact,e_email,e_dob,e_doj,d_id,q_id) values('"+name+"','"+age+"','"+salary+"','"+number+"','"+email+"','"+dob+"','"+doj+"','"+dept+"','"+qualification+"')");
			
			out.println("Data inserted successfully");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
